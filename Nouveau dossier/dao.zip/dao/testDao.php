<?php
include_once($_SERVER['DOCUMENT_ROOT'] . "/models/Voiture.php");


$voitureDAO = new Voiture;
$voitures = $voitureDAO->findAll();

var_dump($voitures);
