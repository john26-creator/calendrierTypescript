<?php

include_once($_SERVER['DOCUMENT_ROOT'] . "/models/DAO/Voiture.dao.php");

/**
 * Class Voiture
 */
class Voiture extends VoitureDAO
{

  public function findAll () {
    $sql="SELECT * FROM voiture";
    return $this->getSelfObjects($sql);
  }
  
  public function findById($id) {
      $request="SELECT * FROM voiture WHERE id= :id";
      $sth = $this->db->prepare($request);
      $sth->bind_param(':id',$id);
      return $this->getSelfObjectsPreparedStatement($sth);
  }
  
  public function updateVoiture ($voiture) {
      $request = "UPDATE voiture SET couleur = :couleur, immat = :immat, marque= :marque, modele= :modele WHERE id = :id;";
      $sth = $this->db->prepare($request);
      $sth->bind_param(':id',$voiture->getId());
      $sth->bind_param(':couleur', $voiture->getCouleur());
      $sth->bind_param(':marque', $voiture->getMarque());
      $sth->bind_param(':modele', $voiture->getModele());
      $sth->bind_param(':immat', $voiture->getImmat());
      
      return $sth->execute();
  }
  
 public function deleteVoiture ($id) {
     $request = "DELETE FROM voiture WHERE id= :id";
     $sth = $this->db->prepare($request);
     $sth->bind_param(':id',$id);
     return $sth->execute();
 }
  
}


